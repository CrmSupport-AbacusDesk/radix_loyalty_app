import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DistributorDealerWalletPage } from './distributor-dealer-wallet';

@NgModule({
  declarations: [
    DistributorDealerWalletPage,
  ],
  imports: [
    IonicPageModule.forChild(DistributorDealerWalletPage),
  ],
})
export class DistributorDealerWalletPageModule {}
