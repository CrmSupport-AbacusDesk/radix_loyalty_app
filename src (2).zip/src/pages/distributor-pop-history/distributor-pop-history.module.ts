import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DistributorPopHistoryPage } from './distributor-pop-history';

@NgModule({
  declarations: [
    DistributorPopHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(DistributorPopHistoryPage),
  ],
})
export class DistributorPopHistoryPageModule {}
